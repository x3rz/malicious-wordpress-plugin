<?php
/**
 * Plugin Name: MalP
 * Version: 1.1.0
 * Author: x3rz
 * Author URI: http:/abc.xyz
 * License: GPL2
 */
?>
